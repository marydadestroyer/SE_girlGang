from django.apps import AppConfig


class AtmConfig(AppConfig):
    name = 'atm'
